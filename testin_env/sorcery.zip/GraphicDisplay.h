//
// Created by michael on 19/07/19.
//

#ifndef CS246A5_GRAPHICDISPLAY_H
#define CS246A5_GRAPHICDISPLAY_H

//#include "Display.h"

class GraphicDisplay {

};


#endif //CS246A5_GRAPHICDISPLAY_H
